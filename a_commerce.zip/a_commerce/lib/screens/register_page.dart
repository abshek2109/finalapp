import 'package:a_commerce/constants.dart';
import 'package:a_commerce/widgets/custom_btn.dart';
import 'package:a_commerce/widgets/custom_input.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/services.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  // Build an alert dialog to display some errors.
  Future<void> _alertDialogBuilder(String error) async {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
            title: Text("Error"),
            content: Container(
              child: Text(error),
            ),
            actions: [
              FlatButton(
                child: Text("Close Dialog"),
                onPressed: () {
                  Navigator.pop(context);
                },
              )
            ],
          );
        });
  }

  // Create a new user account
  Future<String> _createAccount() async {
    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: _registerEmail, password: _registerPassword);
      return null;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        return 'The password provided is too weak.';
      } else if (e.code == 'email-already-in-use') {
        return 'The account already exists for that email.';
      }
      return e.message;
    } catch (e) {
      return e.toString();
    }
  }

  void _submitForm() async {
    // Set the form to loading state
    setState(() {
      _registerFormLoading = true;
    });

    // Run the create account method
    String _createAccountFeedback = await _createAccount();

    // If the string is not null, we got error while create account.
    if (_createAccountFeedback != null) {
      _alertDialogBuilder(_createAccountFeedback);

      // Set the form to regular state [not loading].
      setState(() {
        _registerFormLoading = false;
      });
    } else {
      // The String was null, user is logged in.
      Navigator.pop(context);
    }
  }

  // Default Form Loading State
  bool _registerFormLoading = false;

  // Form Input Field Values
  String _registerEmail = "";
  String _registerPassword = "";

  // Focus Node for input fields
  FocusNode _passwordFocusNode;

  @override
  void initState() {
    _passwordFocusNode = FocusNode();
    super.initState();
  }

  @override
  void dispose() {
    _passwordFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CustomBtn(
                text: "I am Farmer",
                onPressed: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => NewScreen()));
                },
                isLoading: _registerFormLoading,
              ),
              Container(
                padding: EdgeInsets.only(
                  top: 19.0,
                ),
                child: Text(
                  "Create A New Account",
                  textAlign: TextAlign.center,
                  style: Constants.boldHeading,
                ),
              ),
              Column(
                children: [
                  CustomInput(
                    hintText: "Email...",
                    onChanged: (value) {
                      _registerEmail = value;
                    },
                    onSubmitted: (value) {
                      _passwordFocusNode.requestFocus();
                    },
                    textInputAction: TextInputAction.next,
                  ),
                  CustomInput(
                    hintText: "Password...",
                    onChanged: (value) {
                      _registerPassword = value;
                    },
                    focusNode: _passwordFocusNode,
                    isPasswordField: true,
                    onSubmitted: (value) {
                      _submitForm();
                    },
                  ),
                  CustomBtn(
                    text: "Create New Account",
                    onPressed: () {
                      _submitForm();
                    },
                    isLoading: _registerFormLoading,
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(
                  bottom: 14.0,
                ),
                child: CustomBtn(
                  text: "Back To Login",
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  outlineBtn: true,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NewScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Farmers Home/किसान घर'),
        foregroundColor: Color(0xFFFFFFFF),
        backgroundColor: Color(0xFF000000),
      ),
      body: Center(
        child: Wrap(
          direction: Axis.vertical,
          alignment: WrapAlignment.start,
          spacing: 50,
          children: <Widget>[
            ElevatedButton(
              onPressed: () {
                // Respond to button press
                return Scaffold(
                  appBar: AppBar(
                    title: Text('Request Page'),
                    foregroundColor: Color(0xFFFFFFFF),
                    backgroundColor: Color(0xFF000000),
                  ),
                  body: Column(
                    children: [
                      CustomInput(
                        hintText: "Product Name...",
                        onChanged: (value) {},
                        onSubmitted: (value) {},
                        textInputAction: TextInputAction.next,
                      ),
                      CustomInput(
                        hintText: "Phone...",
                        onChanged: (value) {},
                        onSubmitted: (value) {},
                        textInputAction: TextInputAction.next,
                      ),
                      CustomInput(
                        hintText: "Address...",
                        onChanged: (value) {},
                        isPasswordField: true,
                        onSubmitted: (value) {},
                      ),
                      CustomBtn(
                        text: "Submit",
                        onPressed: () {},
                      )
                    ],
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(300, 50),
                primary: Colors.black,
              ),
              child: Text('Product Request/उत्पाद अनुरोध'),
            ),
            ElevatedButton(
              onPressed: () async {
                // Respond to button press
                await launch('https://weather.com/en-IN/weather/today',
                    forceSafariVC: true, forceWebView: true);
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(300, 50),
                primary: Colors.black,
              ),
              child: Text('Weather/मौसम'),
            ),
            ElevatedButton(
              onPressed: () async {
                {
                  await launch(
                      'https://agricoop.gov.in/programmes-schemes-listing',
                      forceSafariVC: true,
                      forceWebView: true);
                }
                // Respond to button press
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(300, 50),
                primary: Colors.black,
              ),
              child: Text('Education/शिक्षा'),
            ),
            ElevatedButton(
                onPressed: () async {
                  {
                    await launch('https://www.farmersstop.com/',
                        forceSafariVC: true, forceWebView: true);
                  }
                },
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(300, 50),
                  primary: Colors.black,
                ),
                child: Text('Products/उत्पादों')),
            ElevatedButton(
              onPressed: () {
                // Respond to button press
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(300, 50),
                primary: Colors.black,
              ),
              child: Text('Orders/गण'),
            ),
          ],
        ),
      ),
    );
  }
}
